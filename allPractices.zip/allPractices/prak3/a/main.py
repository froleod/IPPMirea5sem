import requests
from data import key
from flask import Flask, render_template

app = Flask(__name__)


@app.route('/')
def weather():
    access_key = key

    headers = {
        'X-Yandex-Weather-Key': access_key
    }

    response = requests.get('https://api.weather.yandex.ru/v2/forecast?lat=52.37125&lon=4.89388', headers=headers)
    if response.status_code == 200:
        weather_data = response.json()
        print(weather_data)
        temp = weather_data['fact']['temp']  # Температура
        condition = weather_data['fact']['condition']  # Погодные условия
        pressure = weather_data['fact']['pressure_mm']
        wind = weather_data['fact']['wind_speed']
        return render_template('index.html', temperature=temp, condition=condition, pressure_mm=pressure,
                               wind_speed=wind)
    else:
        return "Ошибка"


if __name__ == '__main__':
    app.run(debug=True)