package ru.froleod.grpc_demo_client;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GrpcDemoClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
