package ru.froleod.grpc_demo_client;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import user.*;

public class GrpcClient {

    private final UserServiceGrpc.UserServiceBlockingStub userServiceStub;
    // developed by Leonid Frolov
    public GrpcClient(String host, int port) {
        // Создание канала для gRPC
        ManagedChannel channel = ManagedChannelBuilder.forAddress(host, port)
                .usePlaintext()
                .build();

        // Создание блока (stub) для вызова RPC методов
        userServiceStub = UserServiceGrpc.newBlockingStub(channel);
    }

    public void registerUser(String username, String password) {
        Conf.UserRequest request = Conf.UserRequest.newBuilder()
                .setUsername(username)
                .setPassword(password)
                .build();

        Conf.UserResponse response = userServiceStub.registerUser(request);
        System.out.println("Register User Response: " + response.getMessage());
    }

    public void loginUser(String username, String password) {
        Conf.LoginRequest request = Conf.LoginRequest.newBuilder()
                .setUsername(username)
                .setPassword(password)
                .build();

        Conf.LoginResponse response = userServiceStub.loginUser(request);
        System.out.println("Login User Response: " + response.getGreeting());
    }

    public void updateUser(String username, String newPassword) {
        Conf.UpdateRequest request = Conf.UpdateRequest.newBuilder()
                .setUsername(username)
                .setNewPassword(newPassword)
                .build();

        Conf.UpdateResponse response = userServiceStub.updateUser(request);
        System.out.println("Update User Response: " + response.getMessage());
    }
    //developed by Leonid Frolov

    public void deleteUser(String username) {
        Conf.DeleteRequest request = Conf.DeleteRequest.newBuilder()
                .setUsername(username)
                .build();

        Conf.DeleteResponse response = userServiceStub.deleteUser(request);
        System.out.println("Delete User Response: " + response.getMessage());
    }

    public static void main(String[] args) {
        // developed by Leonid Frolov
        // Создаем клиента, указывая адрес и порт сервера
        GrpcClient client = new GrpcClient("localhost", 8080);

        client.registerUser("test_user", "test_password");
        client.loginUser("test_user", "test_password");
        client.updateUser("test_user", "new_password");
        client.loginUser("test_user", "new_password");
//        client.deleteUser("test_user");
    }
}


