package ru.froleod.grpc_demo_server.grpc;

import io.grpc.Server;
import io.grpc.netty.shaded.io.grpc.netty.NettyServerBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import ru.froleod.grpc_demo_server.service.UserService;


import java.io.IOException;

@Configuration
public class GrpcServerConfig {

    @Bean
    public NettyServerBuilder nettyServerBuilder(UserService userService) {
        return NettyServerBuilder.forPort(8080).addService(userService);
    }
    //developed by Leonid Frolov

    @Bean
    public Server grpcServer(NettyServerBuilder nettyServerBuilder) throws IOException {
        Server server = nettyServerBuilder.build();
        server.start();
        Runtime.getRuntime().addShutdownHook(new Thread(server::shutdown));
        return server;
    }
}

