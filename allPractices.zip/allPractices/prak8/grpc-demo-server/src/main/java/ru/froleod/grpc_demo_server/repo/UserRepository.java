package ru.froleod.grpc_demo_server.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import ru.froleod.grpc_demo_server.model.User;

import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    //developed by Leonid Frolov

    Optional<User> findByUsername(String username);
}
