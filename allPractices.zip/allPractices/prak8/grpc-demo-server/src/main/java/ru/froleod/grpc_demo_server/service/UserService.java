package ru.froleod.grpc_demo_server.service;

import io.grpc.stub.StreamObserver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.froleod.grpc_demo_server.model.User;
import ru.froleod.grpc_demo_server.repo.UserRepository;
import user.Conf;

import java.util.Optional;

@Service
public class UserService extends user.UserServiceGrpc.UserServiceImplBase {

    @Autowired
    private UserRepository userRepository;
    //developed by Leonid Frolov
    @Override
    public void registerUser(Conf.UserRequest request, StreamObserver<Conf.UserResponse> responseObserver) {
        if (userRepository.findByUsername(request.getUsername()).isPresent()) {
            responseObserver.onNext(Conf.UserResponse.newBuilder().setMessage("User already exists").build());
            responseObserver.onCompleted();
            return;
        }

        User user = new User();
        user.setUsername(request.getUsername());
        user.setPassword(request.getPassword());
        userRepository.save(user);

        responseObserver.onNext(Conf.UserResponse.newBuilder().setMessage("User registered successfully").build());
        responseObserver.onCompleted();
    }

    @Override
    public void loginUser(Conf.LoginRequest request, StreamObserver<Conf.LoginResponse> responseObserver) {
        Optional<User> userOpt = userRepository.findByUsername(request.getUsername());

        if (userOpt.isPresent() && userOpt.get().getPassword().equals(request.getPassword())) {
            responseObserver.onNext(Conf.LoginResponse.newBuilder().setGreeting("Hello, " + request.getUsername() + "!").build());
        } else {
            responseObserver.onNext(Conf.LoginResponse.newBuilder().setGreeting("Invalid credentials").build());
        }
        responseObserver.onCompleted();
    }

    @Override
    public void updateUser(Conf.UpdateRequest request, StreamObserver<Conf.UpdateResponse> responseObserver) {
        Optional<User> userOpt = userRepository.findByUsername(request.getUsername());

        if (userOpt.isPresent()) {
            User user = userOpt.get();
            user.setPassword(request.getNewPassword());
            userRepository.save(user);

            responseObserver.onNext(Conf.UpdateResponse.newBuilder().setMessage("Password updated successfully").build());
        } else {
            responseObserver.onNext(Conf.UpdateResponse.newBuilder().setMessage("User not found").build());
        }
        responseObserver.onCompleted();
    }
    //developed by Leonid Frolov
    @Override
    public void deleteUser(Conf.DeleteRequest request, StreamObserver<Conf.DeleteResponse> responseObserver) {
        Optional<User> userOpt = userRepository.findByUsername(request.getUsername());

        if (userOpt.isPresent()) {
            userRepository.delete(userOpt.get());
            responseObserver.onNext(Conf.DeleteResponse.newBuilder().setMessage("User deleted successfully").build());
        } else {
            responseObserver.onNext(Conf.DeleteResponse.newBuilder().setMessage("User not found").build());
        }
        responseObserver.onCompleted();
    }
}

