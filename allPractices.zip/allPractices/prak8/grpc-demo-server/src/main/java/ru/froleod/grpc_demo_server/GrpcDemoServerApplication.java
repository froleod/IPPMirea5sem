package ru.froleod.grpc_demo_server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GrpcDemoServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(GrpcDemoServerApplication.class, args);
	}

}
