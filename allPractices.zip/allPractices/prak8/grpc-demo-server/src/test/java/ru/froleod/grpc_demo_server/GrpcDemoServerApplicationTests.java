package ru.froleod.grpc_demo_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GrpcDemoServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
